var texto = "Observe que ess amensagem vem do módulo";
module.exports = texto;