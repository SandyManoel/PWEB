var sql = require('mssql');

module.exports=function(){
const sqlConfig = {
    user: 'BD2213003',
    password: 'Naty!2507',
    database: 'BD',
    server: 'Apolo',
    options:{
        encrypt: false,
        trustServerCertificate: true
    }
}
return sql.connect(sqlConfig);
}