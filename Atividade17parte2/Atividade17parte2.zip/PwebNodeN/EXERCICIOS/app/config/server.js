var express = require('express');

var app = express();

app.set('view engine', 'ejs');//mecanismo de engine a ser usado
app.set('views','./app/views');//diretorio onde os arquivos estão

module.exports = app;
